import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

import { refreshAccessToken } from './lib/actions/auth'

export async function middleware(request: NextRequest) {
	const token = request.cookies.get('token')?.value
	const refreshToken = request.cookies.get('refreshToken')?.value
	const user = request.cookies.get('user')
	const isPuplic =
		request.nextUrl.pathname.startsWith('/login') ||
		request.nextUrl.pathname === '/'

	// Allow public routes
	if (isPuplic) {
		if (token && user) {
			// Get return URL from query or default to dashboard
			const returnUrl =
				request.nextUrl.searchParams.get('return_url') || '/dashboard'
			return NextResponse.redirect(new URL(returnUrl, request.url))
		}
		return NextResponse.next()
	}

	// Check for token and user data
	if (!token || !user) {
		if (refreshToken) {
			// Try to refresh the token
			const { data: tokens } = await refreshAccessToken()

			if (tokens) {
				request.cookies.set('token', tokens.access_token)
				request.cookies.set('refreshToken', tokens.refresh_token)
				request.cookies.set('user', JSON.stringify(tokens.user))

				// Token refreshed successfully, continue to requested page
				return NextResponse.next()
			}
		}

		// No token and refresh failed/not available, redirect to login with return URL
		const loginUrl = new URL('/login', request.url)
		loginUrl.searchParams.set(
			'return_url',
			request.nextUrl.pathname + request.nextUrl.search
		)
		return NextResponse.redirect(loginUrl)
	}

	return NextResponse.next()
}

export const config = {
	matcher: [
		/*
		 * Match all request paths except for the ones starting with:
		 * - api (API routes)
		 * - _next/static (static files)
		 * - _next/image (image optimization files)
		 * - favicon.ico (favicon file)
		 * - public folder
		 */
		'/((?!api|_next/static|_next/image|favicon.ico|public).*)'
	]
}
