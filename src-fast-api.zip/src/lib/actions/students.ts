'use server'

import { revalidatePath } from 'next/cache'

import { fetcher } from '@/lib/fetch'
import { ApiResponse, Student } from '@/lib/types'

export async function getStudents() {
	return await fetcher<ApiResponse<Student[]>>('/students')
}

export async function getStudent(id: string) {
	return await fetcher<ApiResponse<Student>>(`/students/${id}`, {
		cache: 'no-store'
	})
}

export async function createStudent(data: FormData) {
	const result = await fetcher<ApiResponse<Student>>('/students', {
		method: 'POST',
		body: data
	})

	revalidatePath('/dashboard/students')
	return result
}

export async function updateStudent(id: string, data: FormData) {
	const result = await fetcher<ApiResponse<Student>>(`/students/${id}`, {
		method: 'PATCH',
		body: data
	})

	revalidatePath('/dashboard/students')
	return result
}

export async function deleteStudent(id: string) {
	const result = await fetcher<ApiResponse<{ message: string }>>(
		`/students/${id}`,
		{
			method: 'DELETE'
		}
	)

	revalidatePath('/dashboard/students')
	return result
}
