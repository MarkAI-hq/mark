export type ApiResponse<T> = {
	data?: T
	error?: { message: string; status: number }
}

export type UserResponse = {
	id: string
	name: string
	email: string
	phone: string
	photo_url: string
	role: string
	is_verified: boolean
	created_at: string
	updated_at: string
}

export type LoginResponse = {
	access_token: string
	refresh_token: string
	user: UserResponse
}

export type RefreshTokenResponse = {
	access_token: string
	refresh_token: string
	user: UserResponse
}

export type DashboardStats = {
	total_courses: number
	total_students: number
	total_exams: number
	marked_papers: number
	recent_activity: Array<{
		id: string
		description: string
		timestamp: string
	}>
	upcoming_deadlines: Array<{
		id: string
		title: string
		due_date: string
	}>
}

export type Student = {
	id: string
	code: string
	name: string
	class: string
	stream: string
	photo_url?: string
	created_by: string
	created_at: string
	updated_at: string
}

export type Subject = {
	id: string
	code: string
	title: string
	description?: string
	created_at: string
	updated_at: string
}

export type Exam = {
	id: string
	title: string
	subject_id: string
	subject: string
	total_marks: number
	question_count: number
	questions?: Question[]
	created_by: string
	created_at: string
	updated_at: string
}

export type CreateExamDto = {
	title: string
	course_id: string
	total_marks: number
	question_count: number
	description?: string
}

export type Question = {
	id: string
	text: string
	type: 'Text' // Can be expanded if there are other types
	components: AssessmentComponent[]
	total_marks: number
	question_number: number
}

export type AssessmentComponent = {
	marks: number
	description: string
}

export type ExamStats = {
	total_students: number
	average_score: number
	highest_score: number
	lowest_score: number
	pass_rate: number
}

export type StudentResult = {
	student_id: string
	student_name: string
	score: number
	total_marks: number
	percentage: number
}

export type QuestionStat = {
	question_number: number
	total_possible_marks: number
	highest_score: number
	lowest_score: number
	average_score: number
	percentage_score: number
	attempts_count: number
}
