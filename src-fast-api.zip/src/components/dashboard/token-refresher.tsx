'use client'

import { useEffect } from 'react'
import { refreshAccessToken } from '@/lib/actions/auth'
import { isTokenExpired } from '@/lib/session-client'
import { useRouter } from 'next/navigation'

export default function TokenRefresher({
	session,
	token,
	refreshToken
}: {
	session: {
		user: {
			id: string
		}
		expires: Date
	} | null
	token: string | undefined
	refreshToken: string | undefined
}) {
	const router = useRouter()

	useEffect(() => {
		async function refresh() {
			if (!session) {
				// No session or session expired
				if (token && isTokenExpired(token) && refreshToken) {
					// Token expired but we have refresh token
					const { data } = await refreshAccessToken()

					if (!data) {
						// router.refresh()
						router.replace('/login')
					}
				} else {
					router.replace('/login')
				}
			}
		}

		refresh()
	}, [session, token, refreshToken, router])

	return null
}
