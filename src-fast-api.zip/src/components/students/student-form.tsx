'use client'

import {
	Dispatch,
	SetStateAction,
	useCallback,
	useEffect,
	useState
} from 'react'
import Image from 'next/image'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { toast } from 'sonner'
import { useDropzone } from 'react-dropzone'
import { Upload, X } from 'lucide-react'

import {
	Dialog,
	DialogContent,
	DialogHeader,
	DialogTitle
} from '@/components/ui/dialog'
import {
	Form,
	FormControl,
	FormField,
	FormItem,
	FormLabel,
	FormMessage
} from '@/components/ui/form'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Student } from '@/lib/types'
import { createStudent, updateStudent } from '@/lib/actions/students'
import { cn } from '@/lib/utils'

const formSchema = z.object({
	code: z.string().min(1, {
		message: 'Student code is required.'
	}),
	name: z.string().min(2, {
		message: 'Name must be at least 2 characters.'
	}),
	class: z.string().min(1, {
		message: 'Class is required.'
	}),
	stream: z.string().optional(),
	photo: z
		.instanceof(File)
		.optional()
		.refine((file) => {
			if (!file) return true
			return (
				file.type === 'image/jpeg' ||
				file.type === 'image/jpg' ||
				file.type === 'image/png'
			)
		}, 'Photo must be a JPEG or PNG file')
		.refine((file) => {
			if (!file) return true
			return file.size <= 5 * 1024 * 1024 // 5MB
		}, 'Photo must be less than 5MB')
})

type TStudentFormData = z.infer<typeof formSchema>

interface StudentFormProps {
	open: boolean
	onOpenChange: (open: boolean) => void
	student?: Student
	setFormOpen: Dispatch<SetStateAction<boolean>>
}

export function StudentForm({
	open,
	onOpenChange,
	student,
	setFormOpen
}: StudentFormProps) {
	const [imagePreview, setImagePreview] = useState<string>()

	const form = useForm<TStudentFormData>({
		resolver: zodResolver(formSchema),
		defaultValues: {
			code: student?.code || '',
			name: student?.name || '',
			class: student?.class || '',
			stream: student?.stream || '',
			photo: undefined
		}
	})

	const onDrop = useCallback(
		(acceptedFiles: File[]) => {
			const file = acceptedFiles[0]
			if (file) {
				form.setValue('photo', file)

				const reader = new FileReader()
				reader.onloadend = () => {
					setImagePreview(reader.result as string)
				}
				reader.readAsDataURL(file)
			}
		},
		[form]
	)

	const { getRootProps, getInputProps, isDragActive } = useDropzone({
		onDrop,
		accept: {
			'image/jpeg': ['.jpg', '.jpeg'],
			'image/png': ['.png']
		},
		multiple: false,
		maxSize: 5 * 1024 * 1024 // 5MB
	})

	const clearFile = () => {
		form.setValue('photo', undefined)
		setImagePreview(undefined)
	}

	// Reset form when student prop changes
	useEffect(() => {
		if (student) {
			form.reset({
				code: student.code,
				name: student.name,
				class: student.class,
				stream: student.stream
			})
			setImagePreview(student.photo_url)
		}
	}, [form, student])

	const onSubmit = async (data: TStudentFormData) => {
		// Create FormData object
		const formData = new FormData()
		formData.append('code', data.code)
		formData.append('name', data.name)
		formData.append('class', data.class)
		if (data.stream) formData.append('stream', data.stream)
		if (data.photo) formData.append('photo', data.photo)

		const { data: result, error } = student
			? await updateStudent(student.id, formData)
			: await createStudent(formData)

		if (error) {
			toast.error('Error', {
				description: error.message
			})
		}

		if (result) {
			toast.success('Success', {
				description: student
					? 'Student updated successfully'
					: 'Student created successfully'
			})
			form.reset()
			setImagePreview(undefined)
			setFormOpen(false)
		}
	}

	return (
		<Dialog open={open} onOpenChange={onOpenChange}>
			<DialogContent className='sm:max-w-[425px]'>
				<DialogHeader>
					<DialogTitle>{student ? 'Edit Student' : 'Add Student'}</DialogTitle>
				</DialogHeader>
				<Form {...form}>
					<form onSubmit={form.handleSubmit(onSubmit)} className='space-y-4'>
						<FormField
							control={form.control}
							name='code'
							render={({ field }) => (
								<FormItem>
									<FormLabel>Student Code</FormLabel>
									<FormControl>
										<Input placeholder='TS-00001' {...field} />
									</FormControl>
									<FormMessage />
								</FormItem>
							)}
						/>
						<FormField
							control={form.control}
							name='name'
							render={({ field }) => (
								<FormItem>
									<FormLabel>Name</FormLabel>
									<FormControl>
										<Input placeholder='John Doe' {...field} />
									</FormControl>
									<FormMessage />
								</FormItem>
							)}
						/>
						<FormField
							control={form.control}
							name='class'
							render={({ field }) => (
								<FormItem>
									<FormLabel>Class</FormLabel>
									<FormControl>
										<Input placeholder='Form 4' {...field} />
									</FormControl>
									<FormMessage />
								</FormItem>
							)}
						/>
						<FormField
							control={form.control}
							name='stream'
							render={({ field }) => (
								<FormItem>
									<FormLabel>Stream (Optional)</FormLabel>
									<FormControl>
										<Input placeholder='East' {...field} />
									</FormControl>
									<FormMessage />
								</FormItem>
							)}
						/>
						<FormField
							control={form.control}
							name='photo'
							render={({ field: { value } }) => (
								<FormItem>
									<FormLabel>Photo (Optional)</FormLabel>
									<FormControl>
										<div
											{...getRootProps({
												className: cn(
													'relative cursor-pointer rounded-lg border-2 border-dashed border-gray-300 dark:border-gray-700 p-6 transition-colors hover:border-gray-400 dark:hover:border-gray-600',
													isDragActive && 'border-primary bg-primary/5'
												)
											})}
										>
											<input {...getInputProps()} />
											<div className='flex flex-col items-center justify-center gap-2 text-center'>
												<Upload className='h-8 w-8 text-muted-foreground' />
												{value || imagePreview ? (
													<div className='relative w-full max-w-sm'>
														<div className='flex items-center justify-between rounded-md border bg-muted p-2'>
															<div className='flex items-center gap-2'>
																<div className='h-10 w-10 shrink-0 rounded bg-white'>
																	{imagePreview ? (
																		<Image
																			src={imagePreview}
																			alt='Preview'
																			className='h-full w-full rounded object-cover'
																			width={40}
																			height={40}
																		/>
																	) : null}
																</div>
																<div className='flex flex-col'>
																	<p className='text-sm font-medium'>
																		{value?.name}
																	</p>
																	<p className='text-xs text-muted-foreground'>
																		{((value?.size ?? 0) / 1024 / 1024).toFixed(
																			2
																		)}
																		MB
																	</p>
																</div>
															</div>
															<Button
																type='button'
																variant='ghost'
																size='icon'
																className='h-8 w-8'
																onClick={(e) => {
																	e.stopPropagation()
																	clearFile()
																}}
															>
																<X className='h-4 w-4' />
															</Button>
														</div>
													</div>
												) : (
													<div className='text-sm'>
														<p className='font-medium'>
															{isDragActive
																? 'Drop the photo here'
																: 'Click or drag & drop'}
														</p>
														<p className='text-muted-foreground'>
															JPEG or PNG (max 5MB)
														</p>
													</div>
												)}
											</div>
										</div>
									</FormControl>
									<FormMessage />
								</FormItem>
							)}
						/>
						<div className='flex justify-end space-x-2'>
							<Button
								type='button'
								variant='outline'
								onClick={() => {
									onOpenChange(false)
									form.reset()
									setImagePreview(undefined)
								}}
							>
								Cancel
							</Button>
							<Button type='submit' disabled={form.formState.isSubmitting}>
								{form.formState.isSubmitting ? 'Saving...' : 'Save'}
							</Button>
						</div>
					</form>
				</Form>
			</DialogContent>
		</Dialog>
	)
}
