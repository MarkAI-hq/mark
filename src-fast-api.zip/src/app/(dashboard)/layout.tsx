// import { redirect } from 'next/navigation'
import { cookies } from 'next/headers'

import { getSession } from '@/lib/session'
import { MainNav } from '@/components/nav/main-nav'
import { UserNav } from '@/components/nav/user-nav'
import { Footer } from '@/components/nav/footer'
import TokenRefresher from '@/components/dashboard/token-refresher'

export default async function DashboardLayout({
	children
}: {
	children: React.ReactNode
}) {
	const cookieStore = await cookies()
	const token = cookieStore.get('token')?.value
	const refreshToken = cookieStore.get('refreshToken')?.value
	const session = await getSession()

	return (
		<div className='flex min-h-screen flex-col'>
			<TokenRefresher
				session={session}
				token={token}
				refreshToken={refreshToken}
			/>
			<header className='sticky top-0 z-50 border-b bg-background'>
				<div className='flex h-16 items-center px-4'>
					<MainNav className='mx-6' />
					<div className='ml-auto flex items-center space-x-4'>
						<UserNav />
					</div>
				</div>
			</header>
			<main className='flex-1 space-y-4 p-8 pt-6'>{children}</main>
			<Footer />
		</div>
	)
}
